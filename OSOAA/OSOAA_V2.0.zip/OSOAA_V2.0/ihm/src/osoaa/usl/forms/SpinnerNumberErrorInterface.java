package osoaa.usl.forms;

public interface SpinnerNumberErrorInterface {
    public String getErrorMessage();

    public String getErrorTitle();
}
