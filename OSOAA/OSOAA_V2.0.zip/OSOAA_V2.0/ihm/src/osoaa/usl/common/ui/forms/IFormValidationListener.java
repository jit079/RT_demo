package osoaa.usl.common.ui.forms;

public interface IFormValidationListener {

	void onFormValidated(boolean isFormValid_);
}
