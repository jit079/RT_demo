package osoaa.bll.domain;

public enum AERSFModelEnum {
	TROPOSPHERIC,
	URBAN,
	MARITIME,
	COASTAL
}
