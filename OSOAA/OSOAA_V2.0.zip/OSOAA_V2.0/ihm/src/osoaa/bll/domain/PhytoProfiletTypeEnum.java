package osoaa.bll.domain;

public enum PhytoProfiletTypeEnum {
	HOMOGENEOUS_PROFILE,
	GAUSSIAN_PROFILE,
	USERFILE_PROFILE
}
