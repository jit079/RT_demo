package osoaa.bll.domain;

public enum SeaBotTypeEnum {
	USER_LAMBERTIAN,
	LIGHT_SAND,
	GREEN_ALGAE,
	BROWN_ALGAE,
	RED_ALGAE
}
