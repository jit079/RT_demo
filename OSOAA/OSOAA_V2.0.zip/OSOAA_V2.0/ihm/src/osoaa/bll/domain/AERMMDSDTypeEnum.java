package osoaa.bll.domain;

public enum AERMMDSDTypeEnum {
	LOG_NORMAL_SIZE_DISTRIBUTION,
	JUNGE_LAW
}
