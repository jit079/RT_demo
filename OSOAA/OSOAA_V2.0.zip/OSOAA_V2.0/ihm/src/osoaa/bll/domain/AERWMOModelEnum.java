package osoaa.bll.domain;

public enum AERWMOModelEnum {
	CONTINENTAL,
	MARITIME,
	URBAN,
	USER_DEFINED
}
