package osoaa.bll.domain;

public enum ViewLevelEnum {
    TOP_OF_ATMOSPHERE,
    SEA_BOTTOM,
    SEA_SURFACE_O_PLUS,
    SEA_SURFACE_O_MINUS,
    USERDEF
}
