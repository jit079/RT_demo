package osoaa.dal.preferences;

import osoaa.bll.exception.InitException;

public class DALGeometricConditionsModel extends AbstractPreferences {

	public DALGeometricConditionsModel()
			throws InitException {
		super("geometricConditions.properties");
	}
}
