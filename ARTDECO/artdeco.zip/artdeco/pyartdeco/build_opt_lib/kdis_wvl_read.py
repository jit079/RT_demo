from __future__ import print_function, division, absolute_import
from builtins import range

import os
import numpy as np

  
def skipcomment(f):
    pos = f.tell()
    tmp = f.readline()
    while tmp.startswith('#'):
        pos = f.tell()
        tmp = f.readline()
    f.seek(pos)


def read_kdis_band(dir_data, kdis_model):

    filename = dir_data+'kdis_'+kdis_model+'_def.dat'
    if not os.path.isfile(filename):
        print("(kdis_coef) ERROR")
        print("            Missing file:", filename)
        exit()
    fdef = open(filename,'r')
    skipcomment(fdef)
    tmp = fdef.readline()
    nmaxai = int(tmp.split()[0])
    skipcomment(fdef)
    tmp = fdef.readline()
    nsp     = int(tmp.split()[0])
    fcont   = np.zeros(nsp) 
    species = []
    skipcomment(fdef)
    for i in range(nsp):
        tmp = fdef.readline()
        #print tmp
        if int(tmp.split()[1]) == 1:
            print(" kdis_coeff ERROR")
            print("            read NOT implemented for concentration dependent species")
            exit()
        species.append(tmp.split()[0])
        fcont[i] = float(tmp.split()[2])
    nsp_c = 0    
    skipcomment(fdef)
    tmp = fdef.readline()
    nwvl = int(tmp.split()[0])
    wvlband = np.zeros((3, nwvl))
    skipcomment(fdef)
    for i in range(nwvl):
        tmp = fdef.readline()                
        wvlband[0,i] = float(tmp.split()[1])
        wvlband[1,i] = float(tmp.split()[2])
        wvlband[2,i] = float(tmp.split()[3])
        if i>0:
            if wvlband[0,i] < wvlband[0,i-1]:
                print(" kdis_coeff ERROR")
                print("            wavelengths must be sorted in increasing order")
                exit()
    skipcomment(fdef)

    return wvlband
