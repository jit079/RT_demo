#!/usr/bin/env python
from __future__ import print_function, division, absolute_import
from builtins import range


import sys
import os
import string
import numpy as np
import h5py

dir_opt  = '/rfs/proj/artdeco_lib/opt/'


if __name__=='__main__':
   
    temp = [190,210,230,250,270]
    res_file = "opt_spherical_ice_tdep_forum.h5"
    
    for it, refind_temp in enumerate(temp):

        print(it, refind_temp)
        
        file_res_tmp  = "opt_spherical_ice_%i"%refind_temp+"K_forum.h5"

        f_tmp = h5py.File(dir_opt+file_res_tmp, 'r')

        grp_tmp    = f_tmp.require_group("sph_ice_%i"%refind_temp)

        if it == 0:
            
            wvl  = np.copy(grp_tmp["axis"]["wavelengths"])
            nwvl = len(wvl)
            reff = np.copy(grp_tmp["axis"]["reff"])
            nreff = len(reff)
            veff = np.copy(grp_tmp["axis"]["veff"])
            nveff= len(veff)
            ang_store = np.copy(grp_tmp["axis"]["phase_angles"])
            nang_store = len(ang_store)
            mu_store  = np.copy(grp_tmp["axis"]["mu"])
            nbetal    = np.copy(grp_tmp["axis"]["nbetal"])
            n_nbetal  = len(nbetal)
            nbetalmax = np.max(nbetal) 

            ntemp = len(temp)
            
            f = h5py.File(dir_opt+res_file, 'a')

            grp    = f.require_group("sph_ice_tdep")

            subgrp = grp.create_group("axis")
            dset = subgrp.create_dataset("wavelengths", data=wvl, dtype='float64')
            dset = subgrp.create_dataset("reff", data=reff, dtype='float64')
            dset = subgrp.create_dataset("veff", data=veff, dtype='float64')
            dset = subgrp.create_dataset("phase_angles", data=ang_store, dtype='float64')
            dset = subgrp.create_dataset("mu", data=mu_store, dtype='float64')
            dset = subgrp.create_dataset("nbetal", data=nbetal, dtype='i')
            dset = subgrp.create_dataset("ibetal", (nbetalmax+1 ,), dtype='i')
            dset[...] = np.arange(nbetalmax+1)    
            dset = subgrp.create_dataset("temp", data=np.array(temp), dtype='float64')

            subgrp = grp.require_group("data")

            dset = subgrp.require_dataset("single_scattering_albedo", (ntemp,nreff, nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions", np.string_("temp,reff,veff,wavelengths"))

            dset = subgrp.require_dataset("Cext", (ntemp,nreff, nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions", np.string_("temp,reff,veff,wavelengths"))
            dset.attrs.create("unit",  np.string_("micron^2"))

            dset = subgrp.require_dataset("extinction_coefficient_over_wc", (ntemp,nreff, nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions",  np.string_("temp,reff,veff,wavelengths"))
            dset.attrs.create("unit",  np.string_("m^2g-1"))

            dset = subgrp.require_dataset("integrate_p11", (ntemp,nreff,nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions", np.string_("temp,reff,veff,wavelengths"))
            dset = subgrp.require_dataset("integrate_p11_recomp", (n_nbetal,ntemp,nreff,nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions", np.string_("nbetal,temp,reff,veff,wavelengths"))
            dset = subgrp.require_dataset("p11_phase_function", (nang_store,ntemp,nreff, nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions", np.string_("mu,temp,reff,veff,wavelengths"))
            dset = subgrp.require_dataset("p21_phase_function", (nang_store,ntemp,nreff, nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions", np.string_("mu,temp,reff,veff,wavelengths"))
            dset = subgrp.require_dataset("p34_phase_function", (nang_store,ntemp,nreff, nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions", np.string_("mu,temp,reff,veff,wavelengths"))
            dset = subgrp.require_dataset("p44_phase_function", (nang_store,ntemp,nreff, nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions", np.string_("mu,temp,reff,veff,wavelengths"))
            dset = subgrp.require_dataset("truncation_coefficient", (n_nbetal,ntemp, nreff, nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions", np.string_("nbetal,temp,reff,veff,wavelengths"))
            dset.attrs.create("truncation", np.string_("dm"))
            dset = subgrp.require_dataset("alpha1_betal", (nbetalmax+1, n_nbetal,ntemp, nreff, nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions", np.string_("ibetal,nbetal,temp,reff,veff,wavelengths"))
            dset.attrs.create("truncation", np.string_("dm"))
            dset = subgrp.require_dataset("alpha2_betal", (nbetalmax+1, n_nbetal,ntemp, nreff, nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions", np.string_("ibetal,nbetal,temp,reff,veff,wavelengths"))
            dset.attrs.create("truncation", np.string_("dm"))
            dset = subgrp.require_dataset("alpha3_betal", (nbetalmax+1, n_nbetal,ntemp, nreff, nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions", np.string_("ibetal,nbetal,temp,reff,veff,wavelengths"))
            dset.attrs.create("truncation", np.string_("dm"))
            dset = subgrp.require_dataset("alpha4_betal", (nbetalmax+1, n_nbetal,ntemp, nreff, nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions", np.string_("ibetal,nbetal,temp,reff,veff,wavelengths"))
            dset.attrs.create("truncation", np.string_("dm"))
            dset = subgrp.require_dataset("beta1_betal", (nbetalmax+1, n_nbetal,ntemp, nreff, nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions", np.string_("ibetal,nbetal,temp,reff,veff,wavelengths"))
            dset.attrs.create("truncation", np.string_("dm"))
            dset = subgrp.require_dataset("beta2_betal", (nbetalmax+1, n_nbetal,ntemp, nreff, nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions", np.string_("ibetal,nbetal,temp,reff,veff,wavelengths"))
            dset.attrs.create("truncation", np.string_("dm"))
            dset = subgrp.require_dataset("recomposed_p11_phase_function", (nang_store, n_nbetal, ntemp,nreff, nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions", np.string_("mu,nbetal,temp,reff,veff,wavelengths"))
            dset.attrs.create("truncation", np.string_("dm"))
            dset = subgrp.require_dataset("recomposed_p22_phase_function", (nang_store, n_nbetal,ntemp, nreff, nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions", np.string_("mu,nbetal,temp,reff,veff,wavelengths"))
            dset.attrs.create("truncation", np.string_("dm"))
            dset = subgrp.require_dataset("recomposed_p33_phase_function", (nang_store, n_nbetal, ntemp,nreff, nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions", np.string_("mu,nbetal,temp,reff,veff,wavelengths"))
            dset.attrs.create("truncation", np.string_("dm"))
            dset = subgrp.require_dataset("recomposed_p21_phase_function", (nang_store, n_nbetal, ntemp,nreff, nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions", np.string_("mu,nbetal,temp,reff,veff,wavelengths"))
            dset.attrs.create("truncation", np.string_("dm"))
            dset = subgrp.require_dataset("recomposed_p34_phase_function", (nang_store, n_nbetal, ntemp,nreff, nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions", np.string_("mu,nbetal,temp,reff,veff,wavelengths"))
            dset.attrs.create("truncation", np.string_("dm"))
            dset = subgrp.require_dataset("recomposed_p44_phase_function", (nang_store, n_nbetal,ntemp, nreff, nveff,nwvl), dtype='float64')
            dset.attrs.create("dimensions", np.string_("mu,nbetal,temp,reff,veff,wavelengths"))
            dset.attrs.create("truncation", np.string_("dm"))
            f.close()



        ssa  = np.copy(grp_tmp["data"]["single_scattering_albedo"])
        Cext = np.copy(grp_tmp["data"]["Cext"])
        Sext_o_WC = np.copy(grp_tmp["data"]["extinction_coefficient_over_wc"])
        p11_integrate = np.copy(grp_tmp["data"]["integrate_p11"])
        p11_recomp_integrate = np.copy(grp_tmp["data"]["integrate_p11_recomp"])
        p11_store = np.copy(grp_tmp["data"]["p11_phase_function"])
        p21_store = np.copy(grp_tmp["data"]["p21_phase_function"])
        p34_store = np.copy(grp_tmp["data"]["p34_phase_function"])
        p44_store = np.copy(grp_tmp["data"]["p44_phase_function"])
        trunc_coeff = np.copy(grp_tmp["data"]["truncation_coefficient"])
        alpha1 = np.copy(grp_tmp["data"]["alpha1_betal"])
        alpha2 = np.copy(grp_tmp["data"]["alpha2_betal"])
        alpha3 = np.copy(grp_tmp["data"]["alpha3_betal"])
        alpha4 = np.copy(grp_tmp["data"]["alpha4_betal"])
        beta1 = np.copy(grp_tmp["data"]["beta1_betal"])
        beta2 = np.copy(grp_tmp["data"]["beta2_betal"])
        p11_recomp_store = np.copy(grp_tmp["data"]["recomposed_p11_phase_function"])
        p22_recomp_store = np.copy(grp_tmp["data"]["recomposed_p22_phase_function"])
        p33_recomp_store = np.copy(grp_tmp["data"]["recomposed_p33_phase_function"])
        p21_recomp_store = np.copy(grp_tmp["data"]["recomposed_p21_phase_function"])
        p34_recomp_store = np.copy(grp_tmp["data"]["recomposed_p34_phase_function"])
        p44_recomp_store = np.copy(grp_tmp["data"]["recomposed_p44_phase_function"])


        f_tmp.close()


        
        f = h5py.File(dir_opt+res_file, 'a')  

        grp    = f.require_group("sph_ice_tdep")
        
        dset = grp["data"]["single_scattering_albedo"]
        dset[it,:,:,:] = ssa
        dset = grp["data"]["Cext"]
        dset[it,:,:,:] = Cext
        dset = grp["data"]["extinction_coefficient_over_wc"]
        dset[it,:,:,:] = Sext_o_WC               
        dset = grp["data"]["integrate_p11"]
        dset[it,:,:,:] = p11_integrate
        dset = grp["data"]["integrate_p11_recomp"]
        dset[:,it,:,:,:] = p11_recomp_integrate
        dset = grp["data"]["p11_phase_function"]
        dset[:,it,:,:,:] = p11_store
        dset = grp["data"]["p21_phase_function"]
        dset[:,it,:,:,:] = p21_store
        dset = grp["data"]["p34_phase_function"]
        dset[:,it,:,:,:] = p34_store
        dset = grp["data"]["p44_phase_function"]
        dset[:,it,:,:,:] = p44_store
        dset = grp["data"]["truncation_coefficient"]
        dset[:,it,:,:,:] = trunc_coeff
        dset = grp["data"]["alpha1_betal"]
        dset[:,:,it,:,:,:] = alpha1
        dset = grp["data"]["alpha2_betal"]
        dset[:,:,it,:,:,:] = alpha2
        dset = grp["data"]["alpha3_betal"]
        dset[:,:,it,:,:,:] = alpha3
        dset = grp["data"]["alpha4_betal"]
        dset[:,:,it,:,:,:] = alpha4
        dset = grp["data"]["beta1_betal"]
        dset[:,:,it,:,:,:] = beta1
        dset = grp["data"]["beta2_betal"]
        dset[:,:,it,:,:,:] = beta2
        dset = grp["data"]["recomposed_p11_phase_function"]
        dset[:,:,it,:,:,:] = p11_recomp_store
        dset = grp["data"]["recomposed_p22_phase_function"]
        dset[:,:,it,:,:,:] = p22_recomp_store
        dset = grp["data"]["recomposed_p33_phase_function"]
        dset[:,:,it,:,:,:] = p33_recomp_store
        dset = grp["data"]["recomposed_p21_phase_function"]
        dset[:,:,it,:,:,:] = p21_recomp_store
        dset = grp["data"]["recomposed_p34_phase_function"]
        dset[:,:,it,:,:,:] = p34_recomp_store
        dset = grp["data"]["recomposed_p44_phase_function"]
        dset[:,:,it,:,:,:] = p44_recomp_store


        f.close()
    



    







    
