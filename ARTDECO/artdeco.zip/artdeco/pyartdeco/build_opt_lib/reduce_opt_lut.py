

import os
import h5py
import numpy as np


dir_opt  = '/rfs/proj/artdeco_lib/opt/'
dir_data = dir_opt





def reduce_opt_liq(lut_name_out, wvl_bounds, veff_out=None, reff_out=None, nbetal_out=None):
    
    res_file = 'opt_liquid_cloud.h5'

    if lut_name_out == res_file:
        return
    
    fin = h5py.File(dir_data+res_file, 'r')    

    wvl = np.copy(fin["liquid_cloud"]["axis"]["wavelengths"])
    reff = np.copy(fin["liquid_cloud"]["axis"]["reff"])
    veff = np.copy(fin["liquid_cloud"]["axis"]["veff"])
    ang_store = np.copy(fin["liquid_cloud"]["axis"]["phase_angles"])
    mu_store = np.copy(fin["liquid_cloud"]["axis"]["mu"])
    nbetal = np.copy(fin["liquid_cloud"]["axis"]["nbetal"])

    ssa                  = fin["liquid_cloud"]["data"]["single_scattering_albedo"]
    Cext                 = fin["liquid_cloud"]["data"]["extinction_coeff"]
    Cext_norm            = fin["liquid_cloud"]["data"]["normed_ext_coeff"]
    p11_integrate        = fin["liquid_cloud"]["data"]["integrate_p11"]
    p11_recomp_integrate = fin["liquid_cloud"]["data"]["integrate_p11_recomp"]
    p11_store = fin["liquid_cloud"]["data"]["p11_phase_function"]
    p21_store = fin["liquid_cloud"]["data"]["p21_phase_function"]
    p34_store = fin["liquid_cloud"]["data"]["p34_phase_function"]
    p44_store = fin["liquid_cloud"]["data"]["p44_phase_function"]
    trunc_coeff = fin["liquid_cloud"]["data"]["truncation_coefficient"]
    alpha1 = fin["liquid_cloud"]["data"]["alpha1_betal"]
    alpha2 = fin["liquid_cloud"]["data"]["alpha2_betal"]
    alpha3 = fin["liquid_cloud"]["data"]["alpha3_betal"]
    alpha4 = fin["liquid_cloud"]["data"]["alpha4_betal"]
    betal1 = fin["liquid_cloud"]["data"]["beta1_betal"]
    betal2 = fin["liquid_cloud"]["data"]["beta2_betal"]
    p11_recomp_store = fin["liquid_cloud"]["data"]["recomposed_p11_phase_function"]
    p22_recomp_store = fin["liquid_cloud"]["data"]["recomposed_p22_phase_function"]
    p33_recomp_store = fin["liquid_cloud"]["data"]["recomposed_p33_phase_function"]
    p21_recomp_store = fin["liquid_cloud"]["data"]["recomposed_p21_phase_function"]
    p34_recomp_store = fin["liquid_cloud"]["data"]["recomposed_p34_phase_function"]
    p44_recomp_store = fin["liquid_cloud"]["data"]["recomposed_p44_phase_function"]

        

    good_wvl = np.argwhere( (wvl >= wvl_bounds[0]) & (wvl <= wvl_bounds[1]))

    if isinstance(veff_out, float):
        good_veff = np.argwhere(veff == veff_out)
    else:
        good_veff = np.argwhere(veff == veff)

    if isinstance(reff_out, float):
        good_reff = np.argwhere(reff == reff_out)
    else:
        good_reff = np.argwhere(reff == reff)

    if isinstance(nbetal_out, int):
        good_nbetal = np.argwhere(nbetal == nbetal_out)
    elif isinstance(nbetal_out, list):
        good_nbetal = [[]]
        for val in nbetal_out: 
            good_nbetal[0].append(np.argwhere(nbetal == val)[0])
    else:
        good_nbetal = np.argwhere(nbetal == nbetal)


    i1_wvl = np.min(good_wvl)
    i2_wvl = np.max(good_wvl)+1
    i1_reff = np.min(good_reff)
    i2_reff = np.max(good_reff)+1
    i1_veff = np.min(good_veff)
    i2_veff = np.max(good_veff)+1
    i1_nbetal = np.min(good_nbetal)
    i2_nbetal = np.max(good_nbetal)+1
    
    # print i1_wvl
    # print i2_wvl 
    # print i1_reff
    # print i2_reff
    # print i1_veff
    # print i2_veff
    # print i1_nbetal
    # print i2_nbetal

    wvl       = wvl[i1_wvl:i2_wvl]
    reff      = reff[i1_reff:i2_reff]
    veff      = veff[i1_veff:i2_veff]
    nbetal    = nbetal[i1_nbetal:i2_nbetal]

    # print "wvl = ", wvl
    # print "reff=",reff
    # print "veff=",veff
    # print "nbetal=",nbetal
    
    nwvl     = len(wvl)
    nreff    = len(reff)
    nveff    = len(veff)
    n_nbetal = len(nbetal)
    nang_store = len(ang_store)
    nbetalmax  = np.max(nbetal)
    

    f = h5py.File(dir_data+lut_name_out, 'a')
    
    grp    = f.require_group("liquid_cloud")

    subgrp = grp.require_group("axis")

    dset = subgrp.require_dataset("wavelengths", (nwvl,), dtype='float64')
    dset[...] = wvl[:]

    dset = subgrp.require_dataset("reff", (nreff,), dtype='float64')
    dset[...] = reff[:]

    dset = subgrp.require_dataset("veff", (nveff,), dtype='float64')
    dset[...] = veff[:]

    dset = subgrp.require_dataset("phase_angles", (nang_store,), dtype='float64')
    dset[...] = ang_store[:]

    dset = subgrp.require_dataset("mu", (nang_store,), dtype='float64')
    dset[...] = mu_store[:]

    dset = subgrp.require_dataset("nbetal", (n_nbetal,), dtype='i')
    dset[...] = nbetal[:]

    dset = subgrp.require_dataset("ibetal", (nbetalmax+1 ,), dtype='i')
    dset[...] = np.arange(nbetalmax+1)    

    subgrp = grp.require_group("data")


       

    dset = subgrp.require_dataset("single_scattering_albedo", (nreff, nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "reff,veff,wavelengths")
    dset[...] = ssa[i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("extinction_coeff", (nreff, nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "reff,veff,wavelengths")
    dset[...] = Cext[i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("normed_ext_coeff", (nreff, nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "reff,veff,wavelengths")
    dset[...] = Cext_norm[i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl]
 
    dset = subgrp.require_dataset("integrate_p11", (nreff,nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "reff,veff,wavelengths")
    dset[...] = p11_integrate[i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("integrate_p11_recomp", (n_nbetal,nreff,nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "nbetal,reff,veff,wavelengths")
    dset[...] = p11_recomp_integrate[i1_nbetal:i2_nbetal, i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("p11_phase_function", (nang_store,nreff, nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,reff,veff,wavelengths")
    dset[...] = p11_store[:, i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("p21_phase_function", (nang_store,nreff, nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,reff,veff,wavelengths")
    dset[...] = p21_store[:, i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("p34_phase_function", (nang_store,nreff, nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,reff,veff,wavelengths")
    dset[...] = p34_store[:, i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("p44_phase_function", (nang_store,nreff, nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,reff,veff,wavelengths")
    dset[...] = p44_store[:, i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("truncation_coefficient", (n_nbetal, nreff, nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "nbetal,reff,veff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = trunc_coeff[i1_nbetal:i2_nbetal, i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("alpha1_betal", (nbetalmax+1, n_nbetal, nreff, nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "ibetal,nbetal,reff,veff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = alpha1[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("alpha2_betal", (nbetalmax+1, n_nbetal, nreff, nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "ibetal,nbetal,reff,veff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = alpha2[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("alpha3_betal", (nbetalmax+1, n_nbetal, nreff, nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "ibetal,nbetal,reff,veff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = alpha3[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("alpha4_betal", (nbetalmax+1, n_nbetal, nreff, nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "ibetal,nbetal,reff,veff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = alpha4[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("beta1_betal", (nbetalmax+1, n_nbetal, nreff, nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "ibetal,nbetal,reff,veff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = betal1[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("beta2_betal", (nbetalmax+1, n_nbetal, nreff, nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "ibetal,nbetal,reff,veff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = betal2[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("recomposed_p11_phase_function", (nang_store, n_nbetal, nreff, nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,nbetal,reff,veff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = p11_recomp_store[:, i1_nbetal:i2_nbetal, i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("recomposed_p22_phase_function", (nang_store, n_nbetal, nreff, nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,nbetal,reff,veff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = p22_recomp_store[:, i1_nbetal:i2_nbetal, i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("recomposed_p33_phase_function", (nang_store, n_nbetal, nreff, nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,nbetal,reff,veff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = p33_recomp_store[:, i1_nbetal:i2_nbetal, i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("recomposed_p21_phase_function", (nang_store, n_nbetal, nreff, nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,nbetal,reff,veff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = p21_recomp_store[:, i1_nbetal:i2_nbetal, i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("recomposed_p34_phase_function", (nang_store, n_nbetal, nreff, nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,nbetal,reff,veff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = p34_recomp_store[:, i1_nbetal:i2_nbetal, i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("recomposed_p44_phase_function", (nang_store, n_nbetal, nreff, nveff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,nbetal,reff,veff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = p44_recomp_store[:, i1_nbetal:i2_nbetal, i1_reff:i2_reff, i1_veff:i2_veff, i1_wvl:i2_wvl] 

    f.close()



    fin.close()


######################################################################################################################



def reduce_opt_ice(lut_name_out, wvl_bounds, reff_out=None, nbetal_out=None):
    

    res_file = 'opt_baum_ice.h5'

    if lut_name_out == res_file:
        return

    fin = h5py.File(dir_data+res_file, 'r')    

    wvl = np.copy(fin["GHM"]["axis"]["wavelengths"])
    reff = np.copy(fin["GHM"]["axis"]["reff"])
    ang_store = np.copy(fin["GHM"]["axis"]["phase_angles"])
    mu_store = np.copy(fin["GHM"]["axis"]["mu"])
    nbetal = np.copy(fin["GHM"]["axis"]["nbetal"])

    ssa                  = fin["GHM"]["data"]["single_scattering_albedo"]
    Cext                 = fin["GHM"]["data"]["extinction_coeff"]
    p11_integrate        = fin["GHM"]["data"]["integrate_p11"]
    p11_recomp_integrate = fin["GHM"]["data"]["integrate_p11_recomp"]
    p11_store = fin["GHM"]["data"]["p11_phase_function"]
    p22_store = fin["GHM"]["data"]["p22_phase_function"]
    p33_store = fin["GHM"]["data"]["p33_phase_function"]
    p44_store = fin["GHM"]["data"]["p44_phase_function"]
    p21_store = fin["GHM"]["data"]["p21_phase_function"]
    p34_store = fin["GHM"]["data"]["p34_phase_function"]
    trunc_coeff = fin["GHM"]["data"]["truncation_coefficient"]
    alpha1 = fin["GHM"]["data"]["alpha1_betal"]
    alpha2 = fin["GHM"]["data"]["alpha2_betal"]
    alpha3 = fin["GHM"]["data"]["alpha3_betal"]
    alpha4 = fin["GHM"]["data"]["alpha4_betal"]
    betal1 = fin["GHM"]["data"]["beta1_betal"]
    betal2 = fin["GHM"]["data"]["beta2_betal"]
    p11_recomp_store = fin["GHM"]["data"]["recomposed_p11_phase_function"]
    p22_recomp_store = fin["GHM"]["data"]["recomposed_p22_phase_function"]
    p33_recomp_store = fin["GHM"]["data"]["recomposed_p33_phase_function"]
    p21_recomp_store = fin["GHM"]["data"]["recomposed_p21_phase_function"]
    p34_recomp_store = fin["GHM"]["data"]["recomposed_p34_phase_function"]
    p44_recomp_store = fin["GHM"]["data"]["recomposed_p44_phase_function"]

    good_wvl = np.argwhere( (wvl >= wvl_bounds[0]) & (wvl <= wvl_bounds[1]))

    if isinstance(reff_out, float):
        good_reff = np.argwhere(reff == reff_out)
    else:
        good_reff = np.argwhere(reff == reff)

    if isinstance(nbetal_out, int):
        good_nbetal = np.argwhere(nbetal == nbetal_out)
    elif isinstance(nbetal_out, list):
        good_nbetal = [[]]
        for val in nbetal_out: 
            good_nbetal[0].append(np.argwhere(nbetal == val)[0])
    else:
        good_nbetal = np.argwhere(nbetal == nbetal)


    i1_wvl = np.min(good_wvl)
    i2_wvl = np.max(good_wvl)+1
    i1_reff = np.min(good_reff)
    i2_reff = np.max(good_reff)+1
    i1_nbetal = np.min(good_nbetal)
    i2_nbetal = np.max(good_nbetal)+1
    
    # print i1_wvl
    # print i2_wvl 
    # print i1_reff
    # print i2_reff
    # print i1_nbetal
    # print i2_nbetal

    wvl       = wvl[i1_wvl:i2_wvl]
    reff      = reff[i1_reff:i2_reff]
    nbetal    = nbetal[i1_nbetal:i2_nbetal]

    # print "wvl = ", wvl
    # print "reff=",reff
    # print "nbetal=",nbetal
    
    nwvl     = len(wvl)
    nreff    = len(reff)
    n_nbetal = len(nbetal)
    nang_store = len(ang_store)
    nbetalmax  = np.max(nbetal)


    

    f = h5py.File(dir_data+lut_name_out, 'a')
    
    grp    = f.require_group("GHM")

    subgrp = grp.require_group("axis")

    dset = subgrp.require_dataset("wavelengths", (nwvl,), dtype='float64')
    dset[...] = wvl[:]

    dset = subgrp.require_dataset("reff", (nreff,), dtype='float64')
    dset[...] = reff[:]

    dset = subgrp.require_dataset("phase_angles", (nang_store,), dtype='float64')
    dset[...] = ang_store[:]

    dset = subgrp.require_dataset("mu", (nang_store,), dtype='float64')
    dset[...] = mu_store[:]

    dset = subgrp.require_dataset("nbetal", (n_nbetal,), dtype='i')
    dset[...] = nbetal[:]

    dset = subgrp.require_dataset("ibetal", (nbetalmax+1 ,), dtype='i')
    dset[...] = np.arange(nbetalmax+1)    



    subgrp = grp.require_group("data")       

    dset = subgrp.require_dataset("single_scattering_albedo", (nreff, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "reff,wavelengths")
    dset[...] = ssa[i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("extinction_coeff", (nreff, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "reff,wavelengths")
    dset[...] = Cext[i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("integrate_p11", (nreff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "reff,wavelengths")
    dset[...] = p11_integrate[i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("integrate_p11_recomp", (n_nbetal,nreff,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "nbetal,reff,wavelengths")
    dset[...] = p11_recomp_integrate[i1_nbetal:i2_nbetal, i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("p11_phase_function", (nang_store,nreff, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,reff,wavelengths")
    dset[...] = p11_store[:, i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("p22_phase_function", (nang_store,nreff, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,reff,wavelengths")
    dset[...] = p22_store[:, i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("p33_phase_function", (nang_store,nreff, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,reff,wavelengths")
    dset[...] = p33_store[:, i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("p21_phase_function", (nang_store,nreff, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,reff,wavelengths")
    dset[...] = p21_store[:, i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("p34_phase_function", (nang_store,nreff, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,reff,wavelengths")
    dset[...] = p34_store[:, i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("p44_phase_function", (nang_store,nreff, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,reff,wavelengths")
    dset[...] = p44_store[:, i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("truncation_coefficient", (n_nbetal, nreff, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "nbetal,reff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = trunc_coeff[i1_nbetal:i2_nbetal, i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("alpha1_betal", (nbetalmax+1, n_nbetal, nreff, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "ibetal,nbetal,reff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = alpha1[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("alpha2_betal", (nbetalmax+1, n_nbetal, nreff, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "ibetal,nbetal,reff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = alpha2[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("alpha3_betal", (nbetalmax+1, n_nbetal, nreff, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "ibetal,nbetal,reff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = alpha3[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("alpha4_betal", (nbetalmax+1, n_nbetal, nreff, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "ibetal,nbetal,reff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = alpha4[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("beta1_betal", (nbetalmax+1, n_nbetal, nreff, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "ibetal,nbetal,reff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = betal1[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("beta2_betal", (nbetalmax+1, n_nbetal, nreff, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "ibetal,nbetal,reff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = betal2[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("recomposed_p11_phase_function", (nang_store, n_nbetal, nreff, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,nbetal,reff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = p11_recomp_store[:, i1_nbetal:i2_nbetal, i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("recomposed_p22_phase_function", (nang_store, n_nbetal, nreff, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,nbetal,reff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = p22_recomp_store[:, i1_nbetal:i2_nbetal, i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("recomposed_p33_phase_function", (nang_store, n_nbetal, nreff, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,nbetal,reff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = p33_recomp_store[:, i1_nbetal:i2_nbetal, i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("recomposed_p21_phase_function", (nang_store, n_nbetal, nreff, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,nbetal,reff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = p21_recomp_store[:, i1_nbetal:i2_nbetal, i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("recomposed_p34_phase_function", (nang_store, n_nbetal, nreff, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,nbetal,reff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = p34_recomp_store[:, i1_nbetal:i2_nbetal, i1_reff:i2_reff,  i1_wvl:i2_wvl]

    dset = subgrp.require_dataset("recomposed_p44_phase_function", (nang_store, n_nbetal, nreff, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,nbetal,reff,wavelengths")
    dset.attrs.create("truncation", "dm")
    dset[...] = p44_recomp_store[:, i1_nbetal:i2_nbetal, i1_reff:i2_reff,  i1_wvl:i2_wvl] 

    f.close()



    fin.close()



######################################################################################################################

def reduce_opt_opac(lut_name_out, wvl_bounds, humidity_out=None, nbetal_out=None, aer_types_out=None):


    res_file = 'opt_opac.h5'

    if lut_name_out == res_file:
        return

    if not isinstance(aer_types_out, list):
        return

    for aer in aer_types_out:

        fin = h5py.File(dir_data+res_file, 'r')    

        wvl = np.copy(fin[aer]["axis"]["wavelengths"])
        humidity = np.copy(fin[aer]["axis"]["humidity"])
        ang_store = np.copy(fin[aer]["axis"]["phase_angles"])
        mu_store = np.copy(fin[aer]["axis"]["mu"])
        nbetal = np.copy(fin[aer]["axis"]["nbetal"])

        ssa                  = fin[aer]["data"]["single_scattering_albedo"]
        Cext_norm            = fin[aer]["data"]["normed_ext_coeff"]
        Cext                 = fin[aer]["data"]["extinction_coeff"]
        p11_integrate        = fin[aer]["data"]["integrate_p11"]
        p11_recomp_integrate = fin[aer]["data"]["integrate_p11_recomp"]
        p11_store = fin[aer]["data"]["p11_phase_function"]
        p44_store = fin[aer]["data"]["p44_phase_function"]
        p21_store = fin[aer]["data"]["p21_phase_function"]
        p34_store = fin[aer]["data"]["p34_phase_function"]
        trunc_coeff = fin[aer]["data"]["truncation_coefficient"]
        alpha1 = fin[aer]["data"]["alpha1_betal"]
        alpha2 = fin[aer]["data"]["alpha2_betal"]
        alpha3 = fin[aer]["data"]["alpha3_betal"]
        alpha4 = fin[aer]["data"]["alpha4_betal"]
        betal1 = fin[aer]["data"]["beta1_betal"]
        betal2 = fin[aer]["data"]["beta2_betal"]
        p11_recomp_store = fin[aer]["data"]["recomposed_p11_phase_function"]
        p22_recomp_store = fin[aer]["data"]["recomposed_p22_phase_function"]
        p33_recomp_store = fin[aer]["data"]["recomposed_p33_phase_function"]
        p21_recomp_store = fin[aer]["data"]["recomposed_p21_phase_function"]
        p34_recomp_store = fin[aer]["data"]["recomposed_p34_phase_function"]
        p44_recomp_store = fin[aer]["data"]["recomposed_p44_phase_function"]


        good_wvl = np.argwhere( (wvl >= wvl_bounds[0]) & (wvl <= wvl_bounds[1]))

        if isinstance(humidity_out, float):
            good_humidity = np.argwhere(humidity == humidity_out)
        elif isinstance(humidity_out, list):
            good_humidity = np.argwhere( (humidity >= humidity_out[0]) & (humidity <= humidity_out[1]))
        else:
            good_humidity = np.argsort(humidity == humidity)
        if isinstance(nbetal_out, int):
            good_nbetal = np.argwhere(nbetal == nbetal_out)
        elif isinstance(nbetal_out, list):
            good_nbetal = [[]]
            for val in nbetal_out: 
                good_nbetal[0].append(np.argwhere(nbetal == val)[0])
        else:
            good_nbetal = np.argwhere(nbetal == nbetal)


        i1_wvl = np.min(good_wvl)
        i2_wvl = np.max(good_wvl)+1
        i1_humidity = np.min(good_humidity)
        i2_humidity = np.max(good_humidity)+1
        i1_nbetal = np.min(good_nbetal)
        i2_nbetal = np.max(good_nbetal)+1

        # print i1_wvl
        # print i2_wvl 
        # print i1_humidity
        # print i2_humidity
        # print i1_nbetal
        # print i2_nbetal

        wvl       = wvl[i1_wvl:i2_wvl]
        humidity  = humidity[i1_humidity:i2_humidity]
        nbetal    = nbetal[i1_nbetal:i2_nbetal]

        # print "wvl = ", wvl
        # print "humidity=",humidity
        # print "nbetal=",nbetal

        nwvl     = len(wvl)
        nhumidity    = len(humidity)
        n_nbetal = len(nbetal)
        nang_store = len(ang_store)
        nbetalmax  = np.max(nbetal)



        f = h5py.File(dir_data+lut_name_out, 'a')

        grp    = f.require_group(aer)

        subgrp = grp.require_group("axis")

        dset = subgrp.require_dataset("wavelengths", (nwvl,), dtype='float64')
        dset[...] = wvl[:]

        dset = subgrp.require_dataset("humidity", (nhumidity,), dtype='float64')
        dset[...] = humidity[:]

        dset = subgrp.require_dataset("phase_angles", (nang_store,), dtype='float64')
        dset[...] = ang_store[:]

        dset = subgrp.require_dataset("mu", (nang_store,), dtype='float64')
        dset[...] = mu_store[:]

        dset = subgrp.require_dataset("nbetal", (n_nbetal,), dtype='i')
        dset[...] = nbetal[:]

        dset = subgrp.require_dataset("ibetal", (nbetalmax+1 ,), dtype='i')
        dset[...] = np.arange(nbetalmax+1)    



        subgrp = grp.require_group("data")       

        dset = subgrp.require_dataset("single_scattering_albedo", (nhumidity, nwvl), dtype='float64')
        dset.attrs.create("dimensions", "humidity,wavelengths")
        dset[...] = ssa[i1_humidity:i2_humidity,  i1_wvl:i2_wvl]

        dset = subgrp.require_dataset("extinction_coeff", (nhumidity, nwvl), dtype='float64')
        dset.attrs.create("dimensions", "humidity,wavelengths")
        dset[...] = Cext[i1_humidity:i2_humidity,  i1_wvl:i2_wvl]

        dset = subgrp.require_dataset("normed_ext_coeff", (nhumidity,nwvl), dtype='float64')
        dset.attrs.create("dimensions", "humidity,wavelengths")
        dset[...] = Cext_norm[i1_humidity:i2_humidity, i1_wvl:i2_wvl]

        dset = subgrp.require_dataset("integrate_p11", (nhumidity,nwvl), dtype='float64')
        dset.attrs.create("dimensions", "humidity,wavelengths")
        dset[...] = p11_integrate[i1_humidity:i2_humidity,  i1_wvl:i2_wvl]

        dset = subgrp.require_dataset("integrate_p11_recomp", (n_nbetal,nhumidity,nwvl), dtype='float64')
        dset.attrs.create("dimensions", "nbetal,humidity,wavelengths")
        dset[...] = p11_recomp_integrate[i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  i1_wvl:i2_wvl]

        dset = subgrp.require_dataset("p11_phase_function", (nang_store,nhumidity, nwvl), dtype='float64')
        dset.attrs.create("dimensions", "mu,humidity,wavelengths")
        dset[...] = p11_store[:, i1_humidity:i2_humidity,  i1_wvl:i2_wvl]

        dset = subgrp.require_dataset("p21_phase_function", (nang_store,nhumidity, nwvl), dtype='float64')
        dset.attrs.create("dimensions", "mu,humidity,wavelengths")
        dset[...] = p21_store[:, i1_humidity:i2_humidity,  i1_wvl:i2_wvl]

        dset = subgrp.require_dataset("p34_phase_function", (nang_store,nhumidity, nwvl), dtype='float64')
        dset.attrs.create("dimensions", "mu,humidity,wavelengths")
        dset[...] = p34_store[:, i1_humidity:i2_humidity,  i1_wvl:i2_wvl]

        dset = subgrp.require_dataset("p44_phase_function", (nang_store,nhumidity, nwvl), dtype='float64')
        dset.attrs.create("dimensions", "mu,humidity,wavelengths")
        dset[...] = p44_store[:, i1_humidity:i2_humidity,  i1_wvl:i2_wvl]

        dset = subgrp.require_dataset("truncation_coefficient", (n_nbetal, nhumidity, nwvl), dtype='float64')
        dset.attrs.create("dimensions", "nbetal,humidity,wavelengths")
        dset.attrs.create("truncation", "dm")
        dset[...] = trunc_coeff[i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  i1_wvl:i2_wvl]

        dset = subgrp.require_dataset("alpha1_betal", (nbetalmax+1, n_nbetal, nhumidity, nwvl), dtype='float64')
        dset.attrs.create("dimensions", "ibetal,nbetal,humidity,wavelengths")
        dset.attrs.create("truncation", "dm")
        dset[...] = alpha1[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  i1_wvl:i2_wvl]

        dset = subgrp.require_dataset("alpha2_betal", (nbetalmax+1, n_nbetal, nhumidity, nwvl), dtype='float64')
        dset.attrs.create("dimensions", "ibetal,nbetal,humidity,wavelengths")
        dset.attrs.create("truncation", "dm")
        dset[...] = alpha2[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  i1_wvl:i2_wvl]

        dset = subgrp.require_dataset("alpha3_betal", (nbetalmax+1, n_nbetal, nhumidity, nwvl), dtype='float64')
        dset.attrs.create("dimensions", "ibetal,nbetal,humidity,wavelengths")
        dset.attrs.create("truncation", "dm")
        dset[...] = alpha3[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  i1_wvl:i2_wvl]

        dset = subgrp.require_dataset("alpha4_betal", (nbetalmax+1, n_nbetal, nhumidity, nwvl), dtype='float64')
        dset.attrs.create("dimensions", "ibetal,nbetal,humidity,wavelengths")
        dset.attrs.create("truncation", "dm")
        dset[...] = alpha4[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  i1_wvl:i2_wvl]

        dset = subgrp.require_dataset("beta1_betal", (nbetalmax+1, n_nbetal, nhumidity, nwvl), dtype='float64')
        dset.attrs.create("dimensions", "ibetal,nbetal,humidity,wavelengths")
        dset.attrs.create("truncation", "dm")
        dset[...] = betal1[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  i1_wvl:i2_wvl]

        dset = subgrp.require_dataset("beta2_betal", (nbetalmax+1, n_nbetal, nhumidity, nwvl), dtype='float64')
        dset.attrs.create("dimensions", "ibetal,nbetal,humidity,wavelengths")
        dset.attrs.create("truncation", "dm")
        dset[...] = betal2[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  i1_wvl:i2_wvl]

        dset = subgrp.require_dataset("recomposed_p11_phase_function", (nang_store, n_nbetal, nhumidity, nwvl), dtype='float64')
        dset.attrs.create("dimensions", "mu,nbetal,humidity,wavelengths")
        dset.attrs.create("truncation", "dm")
        dset[...] = p11_recomp_store[:, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  i1_wvl:i2_wvl]

        dset = subgrp.require_dataset("recomposed_p22_phase_function", (nang_store, n_nbetal, nhumidity, nwvl), dtype='float64')
        dset.attrs.create("dimensions", "mu,nbetal,humidity,wavelengths")
        dset.attrs.create("truncation", "dm")
        dset[...] = p22_recomp_store[:, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  i1_wvl:i2_wvl]

        dset = subgrp.require_dataset("recomposed_p33_phase_function", (nang_store, n_nbetal, nhumidity, nwvl), dtype='float64')
        dset.attrs.create("dimensions", "mu,nbetal,humidity,wavelengths")
        dset.attrs.create("truncation", "dm")
        dset[...] = p33_recomp_store[:, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  i1_wvl:i2_wvl]

        dset = subgrp.require_dataset("recomposed_p21_phase_function", (nang_store, n_nbetal, nhumidity, nwvl), dtype='float64')
        dset.attrs.create("dimensions", "mu,nbetal,humidity,wavelengths")
        dset.attrs.create("truncation", "dm")
        dset[...] = p21_recomp_store[:, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  i1_wvl:i2_wvl]

        dset = subgrp.require_dataset("recomposed_p34_phase_function", (nang_store, n_nbetal, nhumidity, nwvl), dtype='float64')
        dset.attrs.create("dimensions", "mu,nbetal,humidity,wavelengths")
        dset.attrs.create("truncation", "dm")
        dset[...] = p34_recomp_store[:, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  i1_wvl:i2_wvl]

        dset = subgrp.require_dataset("recomposed_p44_phase_function", (nang_store, n_nbetal, nhumidity, nwvl), dtype='float64')
        dset.attrs.create("dimensions", "mu,nbetal,humidity,wavelengths")
        dset.attrs.create("truncation", "dm")
        dset[...] = p44_recomp_store[:, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  i1_wvl:i2_wvl] 

        f.close()




######################################################################################################################


def get_test_aer():

    # lut_name_out, wvl_bounds, humidity_out=None, nbetal_out=None, aer_types_out=None

    lut_name_out = 'opt_test_aer.h5'

    res_file = 'opt_opac.h5'

    aer = "opac_desert"
    humidity_out  = 50.0
    nbetal_out    = [8,16,32,64]
        
    fin = h5py.File(dir_data+res_file, 'r')    

    wvl_store = np.copy(fin[aer]["axis"]["wavelengths"])
    humidity = np.copy(fin[aer]["axis"]["humidity"])
    ang_store = np.copy(fin[aer]["axis"]["phase_angles"])
    mu_store = np.copy(fin[aer]["axis"]["mu"])
    nbetal = np.copy(fin[aer]["axis"]["nbetal"])

    ssa                  = fin[aer]["data"]["single_scattering_albedo"]
    Cext_norm            = fin[aer]["data"]["normed_ext_coeff"]
    Cext                 = fin[aer]["data"]["extinction_coeff"]
    p11_integrate        = fin[aer]["data"]["integrate_p11"]
    p11_recomp_integrate = fin[aer]["data"]["integrate_p11_recomp"]
    p11_store = fin[aer]["data"]["p11_phase_function"]
    p44_store = fin[aer]["data"]["p44_phase_function"]
    p21_store = fin[aer]["data"]["p21_phase_function"]
    p34_store = fin[aer]["data"]["p34_phase_function"]
    trunc_coeff = fin[aer]["data"]["truncation_coefficient"]
    alpha1 = fin[aer]["data"]["alpha1_betal"]
    alpha2 = fin[aer]["data"]["alpha2_betal"]
    alpha3 = fin[aer]["data"]["alpha3_betal"]
    alpha4 = fin[aer]["data"]["alpha4_betal"]
    betal1 = fin[aer]["data"]["beta1_betal"]
    betal2 = fin[aer]["data"]["beta2_betal"]
    p11_recomp_store = fin[aer]["data"]["recomposed_p11_phase_function"]
    p22_recomp_store = fin[aer]["data"]["recomposed_p22_phase_function"]
    p33_recomp_store = fin[aer]["data"]["recomposed_p33_phase_function"]
    p21_recomp_store = fin[aer]["data"]["recomposed_p21_phase_function"]
    p34_recomp_store = fin[aer]["data"]["recomposed_p34_phase_function"]
    p44_recomp_store = fin[aer]["data"]["recomposed_p44_phase_function"]


    if isinstance(humidity_out, float):
        good_humidity = np.argwhere(humidity == humidity_out)
    elif isinstance(humidity_out, list):
        good_humidity = np.argwhere( (humidity >= humidity_out[0]) & (humidity <= humidity_out[1]))
    else:
        good_humidity = np.argsort(humidity == humidity)
    if isinstance(nbetal_out, int):
        good_nbetal = np.argwhere(nbetal == nbetal_out)
    elif isinstance(nbetal_out, list):
        good_nbetal = [[]]
        for val in nbetal_out: 
            good_nbetal[0].append(np.argwhere(nbetal == val)[0])
    else:
        good_nbetal = np.argwhere(nbetal == nbetal)


    i1_humidity = np.min(good_humidity)
    i2_humidity = np.max(good_humidity)+1
    i1_nbetal = np.min(good_nbetal)
    i2_nbetal = np.max(good_nbetal)+1


    humidity      = humidity[i1_humidity:i2_humidity]
    nbetal    = nbetal[i1_nbetal:i2_nbetal]


    iwvl  = [0, len(wvl_store)/2, len(wvl_store)-1]
    print wvl_store[iwvl]

    wvl = [0.764,0.7665,0.769]
    nwvl     = len(wvl)
    nhumidity    = len(humidity)
    n_nbetal = len(nbetal)
    nang_store = len(ang_store)
    nbetalmax  = np.max(nbetal)



    f = h5py.File(dir_data+lut_name_out, 'a')

    grp    = f.require_group(aer)

    subgrp = grp.require_group("axis")

    dset = subgrp.require_dataset("wavelengths", (nwvl,), dtype='float64')
    dset[...] = wvl[:]

    dset = subgrp.require_dataset("humidity", (nhumidity,), dtype='float64')
    dset[...] = humidity[:]

    dset = subgrp.require_dataset("phase_angles", (nang_store,), dtype='float64')
    dset[...] = ang_store[:]

    dset = subgrp.require_dataset("mu", (nang_store,), dtype='float64')
    dset[...] = mu_store[:]

    dset = subgrp.require_dataset("nbetal", (n_nbetal,), dtype='i')
    dset[...] = nbetal[:]

    dset = subgrp.require_dataset("ibetal", (nbetalmax+1 ,), dtype='i')
    dset[...] = np.arange(nbetalmax+1)    



    subgrp = grp.require_group("data")       

    dset = subgrp.require_dataset("single_scattering_albedo", (nhumidity, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "humidity,wavelengths")
    dset[...] = ssa[i1_humidity:i2_humidity,  iwvl]

    dset = subgrp.require_dataset("extinction_coeff", (nhumidity, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "humidity,wavelengths")
    dset[...] = Cext[i1_humidity:i2_humidity,  iwvl]

    dset = subgrp.require_dataset("normed_ext_coeff", (nhumidity,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "humidity,wavelengths")
    dset[...] = Cext_norm[i1_humidity:i2_humidity, iwvl]

    dset = subgrp.require_dataset("integrate_p11", (nhumidity,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "humidity,wavelengths")

    dset = subgrp.require_dataset("integrate_p11_recomp", (n_nbetal,nhumidity,nwvl), dtype='float64')
    dset.attrs.create("dimensions", "nbetal,humidity,wavelengths")

    dset = subgrp.require_dataset("p11_phase_function", (nang_store,nhumidity, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,humidity,wavelengths")

    dset = subgrp.require_dataset("p21_phase_function", (nang_store,nhumidity, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,humidity,wavelengths")

    dset = subgrp.require_dataset("p34_phase_function", (nang_store,nhumidity, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,humidity,wavelengths")

    dset = subgrp.require_dataset("p44_phase_function", (nang_store,nhumidity, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,humidity,wavelengths")

    dset = subgrp.require_dataset("truncation_coefficient", (n_nbetal, nhumidity, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "nbetal,humidity,wavelengths")
    dset.attrs.create("truncation", "dm")

    dset = subgrp.require_dataset("alpha1_betal", (nbetalmax+1, n_nbetal, nhumidity, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "ibetal,nbetal,humidity,wavelengths")
    dset.attrs.create("truncation", "dm")

    dset = subgrp.require_dataset("alpha2_betal", (nbetalmax+1, n_nbetal, nhumidity, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "ibetal,nbetal,humidity,wavelengths")
    dset.attrs.create("truncation", "dm")

    dset = subgrp.require_dataset("alpha3_betal", (nbetalmax+1, n_nbetal, nhumidity, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "ibetal,nbetal,humidity,wavelengths")
    dset.attrs.create("truncation", "dm")

    dset = subgrp.require_dataset("alpha4_betal", (nbetalmax+1, n_nbetal, nhumidity, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "ibetal,nbetal,humidity,wavelengths")
    dset.attrs.create("truncation", "dm")

    dset = subgrp.require_dataset("beta1_betal", (nbetalmax+1, n_nbetal, nhumidity, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "ibetal,nbetal,humidity,wavelengths")
    dset.attrs.create("truncation", "dm")

    dset = subgrp.require_dataset("beta2_betal", (nbetalmax+1, n_nbetal, nhumidity, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "ibetal,nbetal,humidity,wavelengths")
    dset.attrs.create("truncation", "dm")

    dset = subgrp.require_dataset("recomposed_p11_phase_function", (nang_store, n_nbetal, nhumidity, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,nbetal,humidity,wavelengths")
    dset.attrs.create("truncation", "dm")

    dset = subgrp.require_dataset("recomposed_p22_phase_function", (nang_store, n_nbetal, nhumidity, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,nbetal,humidity,wavelengths")
    dset.attrs.create("truncation", "dm")

    dset = subgrp.require_dataset("recomposed_p33_phase_function", (nang_store, n_nbetal, nhumidity, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,nbetal,humidity,wavelengths")
    dset.attrs.create("truncation", "dm")

    dset = subgrp.require_dataset("recomposed_p21_phase_function", (nang_store, n_nbetal, nhumidity, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,nbetal,humidity,wavelengths")
    dset.attrs.create("truncation", "dm")

    dset = subgrp.require_dataset("recomposed_p34_phase_function", (nang_store, n_nbetal, nhumidity, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,nbetal,humidity,wavelengths")
    dset.attrs.create("truncation", "dm")

    dset = subgrp.require_dataset("recomposed_p44_phase_function", (nang_store, n_nbetal, nhumidity, nwvl), dtype='float64')
    dset.attrs.create("dimensions", "mu,nbetal,humidity,wavelengths")
    dset.attrs.create("truncation", "dm")
    
    # iwvl = [len(wvl_store)/2,len(wvl_store)/2,len(wvl_store)/2]

    for ii in xrange(nwvl):

        f[aer]["data"]["integrate_p11"][:,  ii] = p11_integrate[i1_humidity:i2_humidity,  iwvl[ii]]

        f[aer]["data"]["integrate_p11_recomp"][:, :,  ii] = p11_recomp_integrate[i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  iwvl[ii]]

        f[aer]["data"]["p11_phase_function"][:, :,  ii] = p11_store[:, i1_humidity:i2_humidity,  iwvl[ii]]

        f[aer]["data"]["p21_phase_function"][:, :,  ii] = p21_store[:, i1_humidity:i2_humidity,  iwvl[ii]]

        f[aer]["data"]["p34_phase_function"][:, :,  ii] = p34_store[:, i1_humidity:i2_humidity,  iwvl[ii]]

        f[aer]["data"]["p44_phase_function"][:, :,  ii] = p44_store[:, i1_humidity:i2_humidity,  iwvl[ii]]

        f[aer]["data"]["truncation_coefficient"][:, :,  ii] = trunc_coeff[i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  iwvl[ii]]

        f[aer]["data"]["alpha1_betal"][0:nbetalmax+1, :, :,  ii] = alpha1[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  iwvl[ii]]

        f[aer]["data"]["alpha2_betal"][0:nbetalmax+1, :, :,  ii] = alpha2[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  iwvl[ii]]

        f[aer]["data"]["alpha3_betal"][0:nbetalmax+1, :, :,  ii] = alpha3[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  iwvl[ii]]

        f[aer]["data"]["alpha4_betal"][0:nbetalmax+1, :, :,  ii] = alpha4[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  iwvl[ii]]

        f[aer]["data"]["beta1_betal"][0:nbetalmax+1, :, :,  ii] = betal1[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  iwvl[ii]]

        f[aer]["data"]["beta2_betal"][0:nbetalmax+1, :, :,  ii] = betal2[0:nbetalmax+1, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  iwvl[ii]]

        f[aer]["data"]["recomposed_p11_phase_function"][:, :, :,  ii] = p11_recomp_store[:, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  iwvl[ii]]

        f[aer]["data"]["recomposed_p22_phase_function"][:, :, :,  ii] = p22_recomp_store[:, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  iwvl[ii]]

        f[aer]["data"]["recomposed_p33_phase_function"][:, :, :,  ii] = p33_recomp_store[:, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  iwvl[ii]]

        f[aer]["data"]["recomposed_p21_phase_function"][:, :, :,  ii] = p21_recomp_store[:, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  iwvl[ii]]

        f[aer]["data"]["recomposed_p34_phase_function"][:, :, :,  ii] = p34_recomp_store[:, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  iwvl[ii]]

        f[aer]["data"]["recomposed_p44_phase_function"][:, :, :,  ii] = p44_recomp_store[:, i1_nbetal:i2_nbetal, i1_humidity:i2_humidity,  iwvl[ii]] 





    f.close()






if __name__=='__main__':
      
    
    # wvl_bounds = [0.3, 0.8]
    # nbetal_out = [8,16]

    # reduce_opt_liq('opt_liquid_cloud_PAR.h5', wvl_bounds, veff_out = 0.09, nbetal_out=nbetal_out, reff_out=14.0)
    # reduce_opt_ice('opt_baum_ice_PAR.h5', wvl_bounds, nbetal_out=nbetal_out, reff_out=25.0)

    # # aer_types_out = ["opac_antarctic", 
    # #                  "opac_arctic", 
    # #                  "opac_cont_avg", 
    # #                  "opac_cont_clean", 
    # #                  "opac_cont_polluted", 
    # #                  "opac_desert", 
    # #                  "opac_maritime_clean", 
    # #                  "opac_maritime_polluted", 
    # #                  "opac_maritime_tropical", 
    # #                  "opac_urban"] 

    # aer_types_out = ["opac_antarctic", 
    #                  "opac_cont_clean", 
    #                  "opac_desert", 
    #                  "opac_maritime_clean", 
    #                  "opac_urban"] 


    # reduce_opt_opac("opt_opac_PAR.h5", wvl_bounds, humidity_out=70.0, nbetal_out=nbetal_out, aer_types_out=aer_types_out )





    
    # wvl_bounds = [0.3, 15.0]
    # nbetal_out = [8,16]

    # reduce_opt_liq('opt_liquid_cloud_l8.h5', wvl_bounds, veff_out = 0.09, nbetal_out=nbetal_out, reff_out=14.0)
    # reduce_opt_ice('opt_baum_ice_l8.h5', wvl_bounds, nbetal_out=nbetal_out, reff_out=25.0)

    # aer_types_out = ["opac_antarctic", 
    #                  "opac_arctic", 
    #                  "opac_cont_avg", 
    #                  "opac_cont_clean", 
    #                  "opac_cont_polluted", 
    #                  "opac_desert", 
    #                  "opac_maritime_clean", 
    #                  "opac_maritime_polluted", 
    #                  "opac_maritime_tropical", 
    #                  "opac_urban"] 

    # aer_types_out = ["opac_antarctic", 
    #                  "opac_cont_clean", 
    #                  "opac_desert", 
    #                  "opac_maritime_clean", 
    #                  "opac_urban"] 


    # reduce_opt_opac("opt_opac_l8.h5", wvl_bounds, humidity_out=70.0, nbetal_out=nbetal_out, aer_types_out=aer_types_out )










    #wvl_bounds = [0.3, 20.0]
    #reduce_opt_liq('opt_liquid_cloud_METimCTP.h5', wvl_bounds,  veff_out = 0.09)
    #reduce_opt_ice('opt_baum_ice_METimCTP.h5', wvl_bounds)



