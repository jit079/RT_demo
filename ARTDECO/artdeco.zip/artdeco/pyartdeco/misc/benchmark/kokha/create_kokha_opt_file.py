

import sys
sys.ps1='py>'
import os 
import numpy as np
import pylab as pl
import string

###############################################################

artdeco_dir = '/home/mathieu/work/artdeco/trunk/lib/opt/'
smartg_dir = '/home/mathieu/work/MCCuda/fic/'

filename = 'opt_kokha_aer.dat'

# get the initial values in mcrad1d.dat
f = open( filename, 'r')
line1 =  f.readline()
line2 =  f.readline()
line3 =  f.readline()
line4 =  f.readline()
line5 =  f.readline()
line6 =  f.readline()
line7 =  f.readline()
line8 =  f.readline()
tmp    =  f.readline()
nelem  = int(tmp.split()[0])
line10 =  f.readline()
tmp    =  f.readline()
nwvl   = int(tmp.split()[0])
line12 =  f.readline()

wvl    = np.zeros(nwvl)
nteta  = np.zeros(nwvl, dtype=int)
Cext   = np.zeros(nwvl)
SSA    = np.zeros(nwvl)
g      = np.zeros(nwvl)
for i in range(nwvl):
    tmp = f.readline()
    wvl[i]   = float(tmp.split()[0])
    nteta[i] = int(tmp.split()[1])
    Cext[i]  = float(tmp.split()[2])
    SSA[i]   = float(tmp.split()[3])
    g[i]     = float(tmp.split()[4])
tmp = f.readline()
tmp = f.readline()
tmp = f.readline()
mu = np.zeros(nteta[0])
F11= np.zeros(nteta[0])
F44= np.zeros(nteta[0])
F21= np.zeros(nteta[0])
F34= np.zeros(nteta[0])
for i in range(nteta[0]):
    tmp = f.readline()
    mu[i]   = float(tmp.split()[0])
    F11[i]  = float(tmp.split()[1])
    F44[i]  = float(tmp.split()[2])
    F21[i]  = float(tmp.split()[3])
    F34[i]  = float(tmp.split()[4])
f.close()


# new ARTDECO file
f = open(artdeco_dir+filename,'w')
f.write(line1)
f.write(line2)
f.write(line3)
f.write(line4)
f.write(line5)
f.write(line6)
f.write(line7)
f.write(line8)
f.write(line8)
f.write('%6i'%nelem+ '\n')
f.write(line10)
f.write('%6i'%nwvl+ '\n')
f.write(line12)
for i in range(nwvl):
    s = '%10.5f'%wvl[i]+'      '+'%i'%nteta[i]+'      '+'%10.5f'%Cext[i]+'         '+'%10.5f'%SSA[i]+'         '+'%10.5f'%g[i]+ '\n'
    f.write(s)
f.write('# Phase matrix \n')
for i in range(nwvl):
    f.write('# lambda = %10.5f'%wvl[i]+ '\n')
    f.write('#         u                 F11              F44               F21               F34  \n') 
    for j in range(nteta[i]):
        s = '%14.7e'%mu[j]+'  '+'%14.7e'%F11[j]+'  '+'%14.7e'%F44[j]+'  '+'%14.7e'%F21[j]+'  '+'%14.7e'%F34[j]+ '\n'
        f.write(s)
f.close()


# file for SMART-G
f = open(smartg_dir+filename,'w')
f.write('%f \n'%(1.00))
f.write('%i \n'%nteta[0])
for j in range(nteta[0]-1, -1, -1):
    s = '%14.7e'%( np.arccos(mu[j]) * 180.0 / np.pi )+'%14.7e'%(F11[j] + F21[j])+'  '+'%14.7e'%(F11[j] - F21[j])+'  '+'%14.7e'%F44[j]+ '  0.0   \n'
    f.write(s)
f.close()






# lambda =  0.412
#         u                 F11              F44               F21               F34  


# f.write('#  for use in ARTDECO \n')
# f.write('# \n')
# f.write('# nlambda \n')
# f.write('%6i'%nlamb+ '\n')
# f.write('# \n')
# f.write('# lamb(microns)    transmission \n')
# for i in range(nlamb):
#     s = '%10.5f'%lamb[i]+'  '+'%10.5f'%(trans[i])+ '\n'
#     f.write(s)
# f.close()

 
