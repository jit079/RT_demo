from __future__ import print_function, division, absolute_import
from builtins import range

import numpy as np
from scipy.optimize import brentq


def wvl4tau(tau, P):

    return brentq(diff_tau, 0.01, 1000., args=(tau, P)) 
    
    
def diff_tau(wvl, tau, P):

    return  tau - get_tau_rayleigh(wvl, P)
    
    

def get_tau_rayleigh(wvl, P):

    # P   in hPa
    # wvl in microns
    
    P0 = 1013.25       

    tau = (0.008569 * pow(wvl,-4.0)) * (1.0 + (0.0113 * pow(wvl,-2.0)) + (0.00013*pow(wvl,-4.0)))

    tau_rayleigh = tau * P / P0

    if (tau_rayleigh < 0.0) :
        tau_rayleigh = 0.0

    return tau_rayleigh


    
if __name__=='__main__':

    #print(get_tau_rayleigh( 0.412,  1013.0 ))
    print(wvl4tau( 0.1,  1013.0 ))
