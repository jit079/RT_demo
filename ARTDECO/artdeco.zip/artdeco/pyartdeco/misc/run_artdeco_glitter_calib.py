#!/usr/bin/env python

# This was developped by Mathieu Compiegne at HYGEOS

import numpy as np
from artdeco_calib_glitter import artdeco_calib_glitter

if __name__=='__main__':

    dir_data = "/home/mathieu/tmp/data_artdeco_glitter_calib/"

    scene_var = {
        "sza"         : np.array([35.0, 37.0, 25.6, 31.0]),
        "vza"         : np.array([25.0, 26.0, 25.6, 25.9]),
        "raa"         : np.array([90.0, 94.5, 0.0,  180.0 ]),
        "windspeed"   : np.array([5.0,  6.45, 7.5,  8.5]),
        "aot550"      : np.array([0.1,  0.05, 0.2,  0.3]),
        "watercolumn" : np.array([3.5,  3.4,  3.0,  2.5]),
        "ozone"       : np.array([300,  300., 301., 305.]),
        "chloro"      : np.array([0.0,  0.0,  0.0,  0.0]),
    }
    aer_type   = "opac_maritime_clean"
    #aer_type   = "opac_desert"
    instrument = "parasol"
    band_ind   = 2 # starting 1 
    wvl, refl = artdeco_calib_glitter(dir_data, instrument, band_ind, aer_type, scene_var, ascii_kdis=False)
    print(wvl)
    print(refl)