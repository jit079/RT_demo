
rm -rf ../out/*
  