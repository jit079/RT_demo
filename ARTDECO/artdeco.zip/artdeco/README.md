ARTDECO is an atmopsheric radiative transfer suite (likewise LibRadtran).

In order to install ARTDECO:

1) git clone git@gitlab.com:hygeos/artdeco.git  <br />

2) Create some directories  <br />

cd  artdeco/fortran/ <br />
mkdir f2py <br />
mkdir mod <br />
mkdir obj <br />
mkdir out <br />

3) You can now compile the code from artdeco/fortran/src/

make

   
4) To get library files

From hygeos :
   ln -s /rfs/proj/artdeco_lib lib (only works at HYGEOS) <br />

From any where else :
    ask mc@hygeos.com